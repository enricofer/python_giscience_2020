from django.shortcuts import render
from .models import Post
from .forms import PostForm
from django.contrib.auth.decorators import login_required

def post_list(request):
    post_inseriti = Post.objects.all()
    parametri = {
        "blog_title": "Il mio blog in Django",
        "posts": post_inseriti
    }
    return render(request,"blog/post_list.html", parametri)

def post_detail(request,id):
    detail = Post.objects.get(pk=id)
    parameters = {
        "blog_title": "Il mio blog in Django" ,
        "post": detail
    }
    return render(request, "blog/post_detail.html", parameters)

@login_required
def post_new(request):
	if request.POST:
		form = PostForm(request.POST)
		if form.is_valid():
			post = form.save(commit=False)
			post.author = request.user
			user = request.user
			post.save()
			return post_detail(request, id=post.pk)
	else:
		form = PostForm()
		return render(request, 'blog/post_form.html', {'form': form})

@login_required
def post_edit(request, id):
    post = Post.objects.get(pk=id)
    if request.method == "POST":
        form = PostForm(request.POST, instance=post)
        if form.is_valid():
            post = form.save(commit=False)
            post.author = request.user
            post.save()
            return post_detail(request, id=post.pk)
    else:
        form = PostForm(instance=post)
    return render(request, 'blog/post_form.html', {'form': form})
